
#include "mpi.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "sys/stat.h"
#include "mapreduce.h"
#include "keyvalue.h"
#include <bits/stdc++.h>

using namespace MAPREDUCE_NS;

void readfile(int, char *, int, KeyValue *, void *);
void initialize(char *, int, char *, int, int *, KeyValue *, void *);
void mapper(uint64_t, char *, int , char *, int, KeyValue *, void *);
void reducer(char *, int, char *, int, int *, KeyValue *, void *);
void reduce_dangling(char *, int, char *, int, int *, KeyValue *, void *);
void map_imp(uint64_t, char *, int , char *, int, KeyValue *, void *);
void map_imp_diff(uint64_t, char *, int , char *, int, KeyValue *, void *);



float* importance;
float tolerance = 1e-5;
float alpha = 0.85;

/* ---------------------------------------------------------------------- */

int main(int narg, char **args)
{
  MPI_Init(&narg,&args);

  int me,nprocs;
  MPI_Comm_rank(MPI_COMM_WORLD,&me);
  MPI_Comm_size(MPI_COMM_WORLD,&nprocs);



  MapReduce *mr = new MapReduce(MPI_COMM_WORLD);
  MapReduce *mr_helper = new MapReduce(MPI_COMM_WORLD);

  mr->verbosity = 0; //how much summary
  mr->timer = 0;//timing summary
  //mr->memsize = 1;
  //mr->outofcore = 1;
  mr_helper->verbosity = 0; //how much summary
  mr_helper->timer = 0;//timing summary

  MPI_Barrier(MPI_COMM_WORLD);
  double tstart = MPI_Wtime();

  int n_links = mr->map(nprocs, 1, &args[1], 0, 0, '\n', 20, readfile, NULL);
  int n_pages = mr->collate(NULL);
  // if(me == 0)
  // {
  //   std::cout<<"***************"<<std::endl;
  //   std::cout<<"no. of links: "<<n_links<<std::endl;
  //   std::cout<<"no. of pages: "<<n_pages<<std::endl;
  // }
  assert(mr->reduce(initialize,&n_pages) == n_pages);


  importance = new float[n_pages+1];
  importance[0] = 1;
  for(int i=1;i<n_pages+1;i++)
    importance[i] = 1.0/n_pages;
  float error = 1.0;
  int max_loops = 100;
  int loops = 0;
  while(error>tolerance)
  {
    loops++;

    int results = mr->map(mr, mapper, &n_pages);
    // mr->print(-1, 1, 3, 0);
    int collate_var = mr->collate(NULL);
    assert( collate_var == n_pages ||  collate_var == (n_pages+1));
    mr->reduce(reduce_dangling, &n_pages);
    assert(mr->collate(NULL) == n_pages);
    // if (me ==0)
      // std::cout<<"no. results: "<<results<<std::endl;
    assert(mr->reduce(reducer,&n_pages) == n_pages);

    mr_helper->map(mr, map_imp, &n_pages);
    mr_helper->gather(1);
    mr_helper->broadcast(0);
    importance[0] = 0;
    mr_helper->map(mr_helper, map_imp_diff, importance);
    error = importance[0];
    if(loops>max_loops)
      break;

  }

  // std::cout<<"no. of loops: "<<loops<<std::endl;

  if (me==0)
  {
    std::ofstream outFile;
    outFile.open(args[3]);

    float importance_sum = 0;
    for(int i=0;i<n_pages;i++)
        {
            // std::cout<<i<<" = "<<importance[i+1]<<"\n";
            outFile<<i<<" = "<<importance[i+1]<<"\n";
            importance_sum+=importance[i+1];
        }
    // std::cout<<"s = "<<importance_sum<<"\n";
    outFile<<"s = "<<importance_sum<<"\n";
    outFile.close();
  }

  delete mr;
  delete importance;

  double tend = MPI_Wtime();

  if (me==0)
    std::cout<<"mr-pr-mpi-base.cpp "<<args[1]<<" "<<nprocs<<" "<<tend-tstart<<std::endl;

  MPI_Finalize();
}


void readfile(int itask, char *str, int size, KeyValue *kv, void *ptr)
{
  float word1f, word2f;
  char whitespace[6] = {' ','\t','\n','\f','\r','\0'};
  char *word1 = strtok(str,whitespace);
  char *word2 = strtok(NULL,whitespace);

  int max_page = 0;
  while (word1) {
    max_page = std::max({max_page,std::atoi(word1),std::atoi(word2)});
    word1f = (float)(std::atoi(word1));
    word2f = (float)(std::atoi(word2));
    kv->add((char*)&word1f,sizeof(float),(char*)&word2f,sizeof(float));
    // std::cout<<std::atoi(word1)<<" "<<std::atoi(word2)<<std::endl;
    word1 = strtok(NULL,whitespace);
    word2 = strtok(NULL,whitespace);
  }

  for(float i=0;i<=max_page;i++)
    kv->add((char*)&i,sizeof(float),NULL,0);
}

void initialize(char *key, int keybytes, char *multivalue, int nvalues, int *valuebytes, KeyValue *kv, void *ptr)
{
  int n_pages = *(int*)ptr;

  int n_outgoing_links = 0;
  for(int i=0; i<nvalues;i++)
    if(valuebytes[i])
      n_outgoing_links++;

  // std::cout<<"key: "<<std::atoi(key)<<" no. of n_outgoing_links: "<<n_outgoing_links<<std::endl;

  float pg[n_outgoing_links+1];

  pg[0] = 1.0/n_pages;

  int offset = 0;
  int pg_index = 1;
  for(int i=0; i<nvalues;i++)
  {
    if(valuebytes[i])
    {
      pg[pg_index] = *(float*)(multivalue + offset);
      pg_index++;
    }
    offset+=valuebytes[i];
  }
  assert(pg_index == n_outgoing_links + 1);

  kv->add(key,keybytes,(char *) pg,sizeof(float)*(n_outgoing_links + 1));
}

// First element is 0 if importance info, 1 for outgoing links info
void mapper(uint64_t itask, char *key, int keybytes, char *value, int valuebytes, KeyValue *kv, void *ptr)
{
  float* pg = (float*) value;
  float importance = pg[0];
  int n_outgoing_links = valuebytes/sizeof(float) - 1;
  int n_pages = *(int*)ptr;
  //for outgoing links
  pg[0] = 1;

  assert(keybytes==sizeof(float));
  kv->add(key,keybytes,(char*)pg,valuebytes);

  //sending importance contribution to outgoing links
  for (int i = 0;i<n_outgoing_links;i++)
  {
    // std::cout<<pg[i+1]<<std::endl;
    float imp_contri[2];
    imp_contri[0] = 0;
    imp_contri[1] = importance/n_outgoing_links;
    kv->add((char*)&pg[i+1],sizeof(float),(char *) imp_contri,sizeof(float)*2);
  }

  //sending importance contribution for dangling nodes
  if(n_outgoing_links==0)
  {
    float i = -1;
    float imp_contri[2];
    imp_contri[0] = 0;
    imp_contri[1] = importance;
    kv->add((char*)&i,sizeof(float),(char *) imp_contri,sizeof(float)*2);
  }


}

void reducer(char *key, int keybytes, char *multivalue, int nvalues, int *valuebytes, KeyValue *kv, void *ptr)
{
  int n_pages = *(int*)ptr;
  int offset =0;
  float importance = (1-alpha)/n_pages;
  float* pg;
  int n_outgoing_links;
  for(int i=0; i<nvalues;i++)
  {
    float* pkt = (float*)(multivalue + offset);
    offset+=valuebytes[i];
    if(pkt[0] == 0)//imp_contri
      importance+=alpha*pkt[1];
    else
    {
      pg = pkt;
      n_outgoing_links = valuebytes[i]/sizeof(float) -1;
    }
  }

  pg[0] = importance;

  // std::cout<<*(float*)key<<" = "<<importance<<std::endl;
  kv->add(key,keybytes,(char *) pg,sizeof(float)*(n_outgoing_links+1));

}

void reduce_dangling(char *key, int keybytes, char *multivalue, int nvalues, int *valuebytes, KeyValue *kv, void *ptr)
{
  int n_pages = *(int*)ptr;
  int offset =0;
  float pg_num = *(float*)key;

  if(pg_num==-1)
  {
    float dangling_sum = 0;
    for(int i=0; i<nvalues;i++)
    {
      float* pkt = (float*)(multivalue + offset);
      offset+=valuebytes[i];
      dangling_sum+=pkt[1];
    }

    for(float i=0;i<n_pages;i++)
    {
      float imp_contri[2];
      imp_contri[0] = 0;
      imp_contri[1] = dangling_sum/n_pages;
      kv->add((char*)&i,sizeof(float),(char *) imp_contri,sizeof(float)*2);
    }
  }
  else
  {
    for(int i=0; i<nvalues;i++)
    {
      kv->add(key,sizeof(float),multivalue + offset,valuebytes[i]);
      offset+=valuebytes[i];
    }
  }
}


void map_imp(uint64_t itask, char *key, int keybytes, char *value, int valuebytes, KeyValue *kv, void *ptr)
{
  kv->add(key,keybytes,value,sizeof(float));
}

void map_imp_diff(uint64_t itask, char *key, int keybytes, char *value, int valuebytes, KeyValue *kv, void *ptr)
{
  importance[0] += std::abs(importance[int(*(float*)key) + 1] - *(float*)value);
  importance[int(*(float*)key) + 1] = *(float*)value;
}
