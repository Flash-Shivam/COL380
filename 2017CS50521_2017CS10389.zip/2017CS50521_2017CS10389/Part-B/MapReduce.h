#ifndef MAPREDUCE_H
#define MAPREDUCE_H

#include<bits/stdc++.h>

#include <mpi.h>

void vec_int_to_charst(std::vector<int>, char* c, int* nbtyes);
void vec_charst_to_charst(std::vector<char*>, std::vector<int> nbytes_list, char* c, int* nbytes);

std::vector<int> charst_to_vec_int(char*c,int* nbytes);
std::vector<char*> charst_to_vec_charst(char*c,std::vector<int> nbytes_list);



struct cmp_charst
{
    bool operator()(const std::pair<char*, int> p1, const std::pair<char*, int> p2) const
    {
        if(p1.second!=p2.second)
            return p1.second<p2.second;

        return memcmp(p1.first, p2.first, p1.second)<0;
    }
};


class KeyValue
{

public:

  std::vector<char*> keys;
  std::vector<char*> values;
  std::vector<int> keybytes_list;
  std::vector<int> valuebytes_list;


  void add(char* key, int keybytes, char* value, int valuebytes);
  void pr();

  ~KeyValue();

};

class KeyMultiValue
{

  std::map< std::pair<char*, int>, int, cmp_charst> hash_key;

public:
  std::vector<char*> keys;
  std::vector<std::vector<char*> > multivalues;
  std::vector<int> keybytes_list;
  std::vector<std::vector<int> > valuebytes_lists_list;

  void add(char* key, int keybytes, char* value, int valuebytes);

  ~KeyMultiValue();


};

class MapReduce
{

    void encode_kv(KeyValue *kv, char* &c, int* nbytes);
    void decode_kv(char*c, int* nbytes, KeyValue* kv);
    void addKeyValue(KeyValue* kv, KeyValue* kv_temp);
    void kv_to_kmv(KeyValue* kv, KeyMultiValue* kmv);


public:

    KeyValue* kv;
    KeyMultiValue* kmv;
    MPI_Comm mpi_comm;

    MapReduce(MPI_Comm mpi_comm);

    void reduce(void (*myreduce)(char *, int, char *, int, int *, KeyValue *, void *), void * ptr);

    void map(int nmap, std::string filename, void (*mymap)(int, char *, int, KeyValue *, void *), void *ptr);
    void map(MapReduce *mr2, void (*mymap)(uint64_t, char *, int, char *, int, KeyValue *, void *), void *ptr);

    int collate();

    int gather();

    int broadcast();

};

#endif
