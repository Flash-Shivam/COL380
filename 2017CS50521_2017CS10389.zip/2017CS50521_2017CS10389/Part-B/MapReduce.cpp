#include "MapReduce.h"
#include <mpi.h>
#include <bits/stdc++.h>

void vec_int_to_charst(std::vector<int> vec, char* c, int* nbytes)
{
  *nbytes = vec.size()*sizeof(int);

  int* temp = (int*)c;

  for(int i=0;i<vec.size();i++)
    temp[i] = vec[i];
}

void vec_charst_to_charst(std::vector<char*> vec, std::vector<int> nbytes_list, char* c, int* nbytes)
{
  *nbytes = 0;
  for(int i=0;i<nbytes_list.size();i++)
    *nbytes+=nbytes_list[i];

  int offset = 0;

  for(int i=0;i<vec.size();i++)
  {
    for(int j=0;j<nbytes_list[i];j++)
    {
      c[offset] = vec[i][j];
      offset++;
    }
  }
}

std::vector<int> charst_to_vec_int(char*c,int* nbytes)
{
  int n = (*nbytes)/sizeof(int);
  std::vector<int> v;

  int* temp = (int*)c;

  for(int i=0;i<n;i++)
    v.push_back(temp[i]);

  return v;
}

std::vector<char*> charst_to_vec_charst(char*c,std::vector<int> nbytes_list)
{
  int offset = 0;

  std::vector<char*> v;

  for(int i=0;i<nbytes_list.size();i++)
  {
    char *temp = new char[nbytes_list[i]];
    for(int j=0;j<nbytes_list[i];j++)
      temp[j] = c[offset + j];

    v.push_back(temp);

    offset+=nbytes_list[i];

  }

  return v;
}

void KeyValue::add(char* key, int keybytes, char* value, int valuebytes)
{

  assert(keybytes == sizeof(float));

  char* key_temp = new char[keybytes];
  memcpy(key_temp, key, keybytes);
  keys.push_back(key_temp);

  keybytes_list.push_back(keybytes);

  if(value!=NULL)
  {
    char* value_temp = new char[valuebytes];
    memcpy(value_temp, value, valuebytes);
    values.push_back(value_temp);
  }
  else
    values.push_back(NULL);


  valuebytes_list.push_back(valuebytes);

}


void KeyValue::pr()
{
  for(int i=0;i<keys.size();i++)
    std::cout<<"KEY: "<<*(float*)keys[i]<<" with valuebytes: "<<valuebytes_list[i]<<std::endl;
}

KeyValue::~KeyValue()
{
    for (int i = 0; i<keys.size(); i++)
    {
      delete [] keys[i];
      delete [] values[i];
    }
}

KeyMultiValue::~KeyMultiValue()
{
    for (int i = 0; i<keys.size(); i++)
    {
      delete [] keys[i];
      for(int j=0; j<multivalues[i].size(); j++)
        delete[] multivalues[i][j];
    }

    hash_key.clear();
}

void KeyMultiValue::add(char* key, int keybytes, char* value, int valuebytes)
{

  assert(keybytes == sizeof(float));

  if(hash_key.find({key,keybytes})==hash_key.end())
  {
      char* key_temp = new char[keybytes];
      memcpy(key_temp, key, keybytes);
      keys.push_back(key_temp);
      keybytes_list.push_back(keybytes);

      hash_key.insert({{key_temp, keybytes}, keys.size() - 1});


      std::vector<char*> temp1;
      std::vector<int> temp2;
      multivalues.push_back(temp1);
      valuebytes_lists_list.push_back(temp2);
  }

  int key_index = hash_key[{key,keybytes}];


  if(value!=NULL)
  {
    char* value_temp = new char[valuebytes];
    memcpy(value_temp, value, valuebytes);
    multivalues[key_index].push_back(value_temp);
  }
  else
    multivalues[key_index].push_back(NULL);

  valuebytes_lists_list[key_index].push_back(valuebytes);

}






MapReduce::MapReduce(MPI_Comm mpi_comm)
{
  MPI_Comm_dup(mpi_comm, &(this->mpi_comm));
  int me,nprocs;
  MPI_Comm_rank(this->mpi_comm,&me);
  MPI_Comm_size(this->mpi_comm,&nprocs);

  kv = new KeyValue();
  kmv = new KeyMultiValue();

  // std::cout<<me<<" "<<nprocs<<std::endl;

}

void MapReduce::encode_kv(KeyValue* kv, char* &c, int* nbytes)
{
  *nbytes = 0;
  *nbytes += sizeof(int);

  *nbytes+=(kv->keybytes_list.size() + kv->valuebytes_list.size())*sizeof(int);

  *nbytes=std::accumulate(kv->keybytes_list.begin(),kv->keybytes_list.end(),*nbytes);
  *nbytes=std::accumulate(kv->valuebytes_list.begin(),kv->valuebytes_list.end(),*nbytes);


  c = new char[*nbytes];
  int* temp = (int*)c;
  int offset = 0,dump = 0;


  temp[offset] = kv->keybytes_list.size();
  offset+=sizeof(int);

  vec_int_to_charst(kv->keybytes_list, c + offset, &dump);
  offset+=dump;
  vec_int_to_charst(kv->valuebytes_list, c + offset, &dump);
  offset+=dump;

  vec_charst_to_charst(kv->keys, kv->keybytes_list, c + offset, &dump);
  offset+=dump;
  vec_charst_to_charst(kv->values, kv->valuebytes_list, c + offset, &dump);
  offset+=dump;
}

void MapReduce::decode_kv(char*c, int* nbytes, KeyValue* kv)
{
  int* temp = (int*)c;
  int offset = 0,dump = 0;

  int nkeys = temp[0];
  offset+=sizeof(int);


  dump = nkeys*sizeof(int);
  kv->keybytes_list = charst_to_vec_int(c + offset,&dump);
  offset+=dump;
  kv->valuebytes_list = charst_to_vec_int(c + offset,&dump);
  offset+=dump;

  dump = std::accumulate(kv->keybytes_list.begin(),kv->keybytes_list.end(),0);
  kv->keys = charst_to_vec_charst(c + offset,kv->keybytes_list);
  offset+=dump;
  dump = std::accumulate(kv->valuebytes_list.begin(),kv->valuebytes_list.end(),0);
  kv->values = charst_to_vec_charst(c + offset,kv->valuebytes_list);
  offset+=dump;

  assert(offset == *nbytes);
}

void MapReduce::addKeyValue(KeyValue* kv1, KeyValue* kv2)
{
  for(int i=0;i<kv2->keys.size();i++)
    kv1->add(kv2->keys[i], kv2->keybytes_list[i], kv2->values[i], kv2->valuebytes_list[i]);
}


void MapReduce::kv_to_kmv(KeyValue* kv, KeyMultiValue* kmv)
{

  for(int i=0;i<kv->keys.size();i++)
   kmv->add(kv->keys[i],kv->keybytes_list[i],kv->values[i],kv->valuebytes_list[i]);

}

int MapReduce::gather()
{
  int me,nprocs;
  MPI_Comm_rank(this->mpi_comm,&me);
  MPI_Comm_size(this->mpi_comm,&nprocs);


  MPI_Status status;

  if(me==0)
  {
    MPI_Request request[nprocs];
    int recvsize[nprocs];           // store datasizes that process will send


    // Collect datasizes to be received
    for (int i = 1;i<nprocs;i++)
      MPI_Recv(recvsize+i, 1, MPI_INT, i, 0, MPI_COMM_WORLD, &status);

    // Allocate memory for the data recieve
    char* recvdata[nprocs];
    for(int i=1;i<nprocs;i++)
    {
        recvdata[i] = new char[recvsize[i]];
        MPI_Irecv(recvdata[i], recvsize[i], MPI_CHAR, i, 0, MPI_COMM_WORLD, &request[i]);
    }

    //Decode all received chunks and add to self's kv
    for(int i=1;i<nprocs;i++)
    {
        MPI_Wait(&request[i], &status);
        KeyValue kv_temp;
        decode_kv(recvdata[i], &recvsize[i], &kv_temp);
        addKeyValue(this->kv, &kv_temp);

        delete [] recvdata[i];
    }

    return kv->keys.size();
  }

  // All processes encode self's kv and send to process 0
  else
  {

    MPI_Request req;

    int nbytes;
    char*c;
    encode_kv(this->kv, c, &nbytes);


    MPI_Send(&nbytes, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    MPI_Isend(c, nbytes, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &req);

    MPI_Wait(&req, &status);

    delete[] c;
    delete this->kv;
    this->kv = new KeyValue();

    return -1;
  }
}

int MapReduce::broadcast()
{
  int me,nprocs;
  MPI_Comm_rank(this->mpi_comm,&me);
  MPI_Comm_size(this->mpi_comm,&nprocs);


  MPI_Status status;

  if(me==0)
  {

    MPI_Request request[nprocs];

    int nbytes;
    char*c;
    encode_kv(this->kv, c, &nbytes);


    // Send datasize to be sent
    for (int i = 1;i<nprocs;i++)
      MPI_Send(&nbytes, 1, MPI_INT, i, 0, MPI_COMM_WORLD);

    for (int i = 1;i<nprocs;i++)
      MPI_Isend(c, nbytes, MPI_CHAR, i, 0, MPI_COMM_WORLD, &request[i]);

    for (int i = 1;i<nprocs;i++)
        MPI_Wait(&request[i],&status);

    delete[] c;

  }
  // All processes recieve a kv from proc 0
  else
  {

    MPI_Request req;

    int nbytes;
    char*c;


    MPI_Recv(&nbytes, 1, MPI_INT, 0, 0, MPI_COMM_WORLD,&status);
    c = new char[nbytes];

    MPI_Irecv(c, nbytes, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &req);
    MPI_Wait(&req, &status);


    delete this->kv;
    this->kv = new KeyValue();
    decode_kv(c, &nbytes, this->kv);

    delete[] c;
  }

  return kv->keys.size();
}

void MapReduce::map(int nmap, std::string filename, void (*mymap)(int, char *, int, KeyValue *, void *), void *ptr)
{
  int me,nprocs;
  MPI_Comm_rank(this->mpi_comm,&me);
  MPI_Comm_size(this->mpi_comm,&nprocs);


  // std::cout<<me<<" "<<filename<<std::endl;
  std::string temp, data="";
  int count = 0;

  std::ifstream file_in;
  file_in.open(filename);
  while(getline(file_in,temp))
  {
    count++;
    if(count%nprocs!=me)
      continue;
    data+=temp+"\n";
  }
  data+='\0';

  delete this->kv;
  this->kv = new KeyValue();



  char *cstr = new char[data.length() + 1];
  strcpy(cstr, data.c_str());
  mymap(me, cstr, data.length() + 1, this->kv, ptr);

  delete [] cstr;

}

void MapReduce::map(MapReduce *mr2, void (*mymap)(uint64_t, char *, int, char *, int, KeyValue *, void *), void *ptr)
{
  int me,nprocs;
  MPI_Comm_rank(this->mpi_comm,&me);
  MPI_Comm_size(this->mpi_comm,&nprocs);

  KeyValue kv_temp;
  addKeyValue(&kv_temp, mr2->kv);


  delete this->kv;
  this->kv = new KeyValue();

  for(int i=0; i<kv_temp.keys.size();i++)
    mymap(me, kv_temp.keys[i], kv_temp.keybytes_list[i], kv_temp.values[i], kv_temp.valuebytes_list[i], this->kv, ptr);

}

void MapReduce::reduce(void (*myreduce)(char *, int, char *, int, int *, KeyValue *, void *), void * ptr)
{
  this->kv = new KeyValue();

  for(int i=0; i<kmv->keys.size();i++)
  {
    int nbytes;
    int nvaluebytes=std::accumulate(kmv->valuebytes_lists_list[i].begin(),kmv->valuebytes_lists_list[i].end(),0);
    char* c = new char[nvaluebytes];
    vec_charst_to_charst(kmv->multivalues[i], kmv->valuebytes_lists_list[i], c, &nbytes);
    int nvaluebytesbytes = kmv->valuebytes_lists_list[i].size()*sizeof(int);
    char* d = new char[nvaluebytesbytes];
    vec_int_to_charst(kmv->valuebytes_lists_list[i], d, &nbytes);
    myreduce(kmv->keys[i], kmv->keybytes_list[i], c, kmv->valuebytes_lists_list[i].size(), (int*) d, kv, ptr);
    delete[] c;
    delete[] d;

  }

  delete this->kmv;
}

int MapReduce::collate()
{
  int me,nprocs;
  MPI_Comm_rank(this->mpi_comm,&me);
  MPI_Comm_size(this->mpi_comm,&nprocs);

  MPI_Request req_send1[nprocs],req_send2[nprocs];
  MPI_Request req_recv1[nprocs],req_recv2[nprocs];
  int nbytes_send[nprocs],nbytes_recv[nprocs];
  char* senddata[nprocs];
  char* recvdata[nprocs];


  MPI_Status status;

  KeyValue kv_list[nprocs];
  // std::cout<<"keys distribution started in: "<<me<<std::endl;
  for(int i=0;i<kv->keys.size();i++)
  {
      int key = (int)*(float*)(kv->keys[i]);
      kv_list[abs(key)%nprocs].add(kv->keys[i],kv->keybytes_list[i],kv->values[i],kv->valuebytes_list[i]);
  }
  // std::cout<<"keys distributed in: "<<me<<std::endl;
  for(int i=0;i<nprocs;i++)
  {
      if(i==me)
        continue;

      encode_kv(&kv_list[i], senddata[i], &nbytes_send[i]);

      MPI_Isend(&nbytes_send[i], 1, MPI_INT, i, 0, MPI_COMM_WORLD, &req_send1[i]);
      // std::cout<<"(I)sent nbytes_send from: "<<me<<" to: "<<i<<std::endl;
      MPI_Irecv(&nbytes_recv[i], 1, MPI_INT, i, 0, MPI_COMM_WORLD, &req_recv1[i]);
      // std::cout<<"(I)received nbytes_recv from: "<<i<<" to: "<<me<<std::endl;

  }


  for(int i=0;i<nprocs;i++)
  {
      if(i==me)
        continue;


      MPI_Wait(&req_send1[i],&status);
      // std::cout<<"waiting to complete send nbytes_send from: "<<me<<" to: "<<i<<std::endl;
      MPI_Isend(senddata[i], nbytes_send[i], MPI_CHAR, i, 0, MPI_COMM_WORLD, &req_send2[i]);
      // std::cout<<"(I)sent data from: "<<me<<" to: "<<i<<std::endl;
  }

  for(int i=0;i<nprocs;i++)
  {
      if(i==me)
        continue;

      // std::cout<<"waiting to complete receive nbytes_recv from: "<<i<<" to: "<<me<<std::endl;
      MPI_Wait(&req_recv1[i],&status);
      recvdata[i] = new char[nbytes_recv[i]];
      MPI_Irecv(recvdata[i], nbytes_recv[i], MPI_INT, i, 0, MPI_COMM_WORLD,&req_recv2[i]);
      // std::cout<<"(I)received data from: "<<i<<" to: "<<me<<std::endl;

  }

  for(int i=0;i<nprocs;i++)
  {
      if(i==me)
        continue;

      // std::cout<<"waiting to complete receive data from: "<<i<<" to: "<<me<<std::endl;
      MPI_Wait(&req_recv2[i],&status);
      KeyValue kv_temp;
      decode_kv(recvdata[i], &nbytes_recv[i], &kv_temp);
      delete[] recvdata[i];
      addKeyValue(&kv_list[me], &kv_temp);
  }

  for(int i=0;i<nprocs;i++)
  {
      if(i==me)
        continue;
      // std::cout<<"waiting to complete send data from: "<<me<<" to: "<<i<<std::endl;
      MPI_Wait(&req_send2[i],&status);
      delete[] senddata[i];
  }

  // std::cout<<"all send recv done: "<<me<<std::endl;

  delete this->kv;
  this->kv = new KeyValue();
  addKeyValue(this->kv,&kv_list[me]);

  // std::cout<<"key value added: "<<me<<std::endl;

  this->kmv = new KeyMultiValue();
  kv_to_kmv(kv, kmv);

  // std::cout<<"kv to kmv done: "<<me<<std::endl;

  int total_keys = 0;
  int temp;
  for(int i=0;i<nprocs;i++)
  {
    MPI_Barrier(mpi_comm);
    // std::cout<<"broadcast: "<<i<<std::endl;
    temp = kmv->keys.size();
    MPI_Bcast(&temp,1,MPI_INT,i,this->mpi_comm);
    total_keys+=temp;

  }

  delete this->kv;
  return total_keys;

}
