
#include <mpi.h>
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "sys/stat.h"
#include "MapReduce.h"

#include <bits/stdc++.h>


void readfile(int, char *, int, KeyValue *, void *);
void initialize(char *, int, char *, int, int *, KeyValue *, void *);
void mapper(uint64_t, char *, int , char *, int, KeyValue *, void *);
void reducer(char *, int, char *, int, int *, KeyValue *, void *);
void reduce_dangling(char *, int, char *, int, int *, KeyValue *, void *);
void map_imp(uint64_t, char *, int , char *, int, KeyValue *, void *);
void map_imp_diff(uint64_t, char *, int , char *, int, KeyValue *, void *);


float* importance;
float tolerance = 1e-5;
float alpha = 0.85;
int max_loops = 100;


float error = 1.0;
int loops = 0;

/* ---------------------------------------------------------------------- */

int main(int narg, char **args)
{
  MPI_Init(&narg,&args);

  int me,nprocs;
  MPI_Comm_rank(MPI_COMM_WORLD,&me);
  MPI_Comm_size(MPI_COMM_WORLD,&nprocs);



  MapReduce *mr = new MapReduce(MPI_COMM_WORLD);
  MapReduce *mr_helper = new MapReduce(MPI_COMM_WORLD);

  MPI_Barrier(MPI_COMM_WORLD);
  double tstart = MPI_Wtime();

  mr->map(nprocs, std::string(args[1]), readfile, NULL);
  int n_pages = mr->collate();
  // std::cout<<"no. of pages: "<<n_pages<<std::endl;
  // mr->kv->pr();
  // if(me == 0)
  // {
  //   std::cout<<"***************"<<std::endl;
  //   std::cout<<"no. of pages: "<<n_pages<<std::endl;
  // }

  mr->reduce(initialize,&n_pages);

  // mr->kv->pr();

  importance = new float[n_pages+1];
  importance[0] = 1;
  for(int i=1;i<n_pages+1;i++)
    importance[i] = 1.0/n_pages;

  while(error>tolerance)
  {
    loops++;

    mr->map(mr, mapper, &n_pages);
    // mr->kv->pr();
    int collate_var = mr->collate();

    // std::cout<<collate_var<<std::endl;

    assert( collate_var == n_pages ||  collate_var == (n_pages+1));
    mr->reduce(reduce_dangling, &n_pages);
    // mr->kv->pr();

    assert(mr->collate() == n_pages);

    mr->reduce(reducer,&n_pages);
    // mr->kv->pr();


    mr_helper->map(mr, map_imp, &n_pages);
    mr_helper->gather();
    mr_helper->broadcast();
    importance[0] = 0;
    mr_helper->map(mr_helper, map_imp_diff, importance);
    error = importance[0];
    // std::cout<<"Error in loop "<<loops<<": "<<error<<std::endl;
    if(loops>max_loops)
      break;


  }

  // std::cout<<"no. of loops: "<<loops<<std::endl;

  if (me==0)
  {
    std::ofstream outFile;
    outFile.open(args[3]);

    float importance_sum = 0;
    for(int i=0;i<n_pages;i++)
        {
            // std::cout<<i<<" = "<<importance[i+1]<<"\n";
            outFile<<i<<" = "<<importance[i+1]<<"\n";
            importance_sum+=importance[i+1];
        }
    // std::cout<<"s = "<<importance_sum<<"\n";
    outFile<<"s = "<<importance_sum<<"\n";
    outFile.close();
  }

  delete mr;
  delete mr_helper;
  delete[] importance;

  double tend = MPI_Wtime();

  if (me==0)
    std::cout<<"mr-pr-mpi.cpp "<<args[1]<<" "<<nprocs<<" "<<tend-tstart<<std::endl;

  MPI_Finalize();

}






void readfile(int itask, char *str, int size, KeyValue *kv, void *ptr)
{
  float word1f, word2f;
  char whitespace[6] = {' ','\t','\n','\f','\r','\0'};
  char *word1 = strtok(str,whitespace);
  char *word2 = strtok(NULL,whitespace);

  int max_page = 0;
  while (word1) {
    max_page = std::max({max_page,std::atoi(word1),std::atoi(word2)});
    word1f = (float)(std::atoi(word1));
    word2f = (float)(std::atoi(word2));
    kv->add((char*)&word1f,sizeof(float),(char*)&word2f,sizeof(float));
    // std::cout<<std::atoi(word1)<<" "<<std::atoi(word2)<<std::endl;
    word1 = strtok(NULL,whitespace);
    word2 = strtok(NULL,whitespace);

  }

  for(float i=0;i<=max_page;i++)
    kv->add((char*)&i,sizeof(float),NULL,0);
}

void initialize(char *key, int keybytes, char *multivalue, int nvalues, int *valuebytes, KeyValue *kv, void *ptr)
{
  int n_pages = *(int*)ptr;

  int n_outgoing_links = 0;
  for(int i=0; i<nvalues;i++)
    if(valuebytes[i])
      n_outgoing_links++;

  // std::cout<<"key: "<<std::atoi(key)<<" no. of n_outgoing_links: "<<n_outgoing_links<<std::endl;

  float pg[n_outgoing_links+1];

  pg[0] = 1.0/n_pages;

  int offset = 0;
  int pg_index = 1;
  for(int i=0; i<nvalues;i++)
  {
    if(valuebytes[i])
    {
      pg[pg_index] = *(float*)(multivalue + offset);
      pg_index++;
    }
    offset+=valuebytes[i];
  }
  assert(pg_index == n_outgoing_links + 1);

  kv->add(key,keybytes,(char *) pg,sizeof(float)*(n_outgoing_links + 1));
}

// First element is 0 if importance info, 1 for outgoing links info
void mapper(uint64_t itask, char *key, int keybytes, char *value, int valuebytes, KeyValue *kv, void *ptr)
{
  float* pg = (float*) value;
  float importance = pg[0];
  int n_outgoing_links = valuebytes/sizeof(float) - 1;
  int n_pages = *(int*)ptr;
  //for outgoing links
  pg[0] = 1;

  assert(keybytes==sizeof(float));
  kv->add(key,keybytes,(char*)pg,valuebytes);

  //sending importance contribution to outgoing links
  for (int i = 0;i<n_outgoing_links;i++)
  {
    // std::cout<<pg[i+1]<<std::endl;
    float imp_contri[2];
    imp_contri[0] = 0;
    imp_contri[1] = importance/n_outgoing_links;
    kv->add((char*)&pg[i+1],sizeof(float),(char *) imp_contri,sizeof(float)*2);
  }

  //sending importance contribution for dangling nodes
  if(n_outgoing_links==0)
  {
    float i = -1;
    float imp_contri[2];
    imp_contri[0] = 0;
    imp_contri[1] = importance;
    kv->add((char*)&i,sizeof(float),(char *) imp_contri,sizeof(float)*2);
  }


}

void reducer(char *key, int keybytes, char *multivalue, int nvalues, int *valuebytes, KeyValue *kv, void *ptr)
{
  int n_pages = *(int*)ptr;
  int offset =0;
  float importance = (1-alpha)/n_pages;
  float* pg;
  int n_outgoing_links;
  for(int i=0; i<nvalues;i++)
  {
    float* pkt = (float*)(multivalue + offset);
    offset+=valuebytes[i];
    if(pkt[0] == 0)//imp_contri
      importance+=alpha*pkt[1];
    else
    {
      pg = pkt;
      n_outgoing_links = valuebytes[i]/sizeof(float) -1;
    }
  }

  pg[0] = importance;

  // std::cout<<*(float*)key<<" = "<<importance<<std::endl;
  kv->add(key,keybytes,(char *) pg,sizeof(float)*(n_outgoing_links+1));

}

void reduce_dangling(char *key, int keybytes, char *multivalue, int nvalues, int *valuebytes, KeyValue *kv, void *ptr)
{
  int n_pages = *(int*)ptr;
  int offset =0;
  float pg_num = *(float*)key;

  if(pg_num==-1)
  {
    float dangling_sum = 0;
    for(int i=0; i<nvalues;i++)
    {
      float* pkt = (float*)(multivalue + offset);
      offset+=valuebytes[i];
      dangling_sum+=pkt[1];
    }

    for(float i=0;i<n_pages;i++)
    {
      float imp_contri[2];
      imp_contri[0] = 0;
      imp_contri[1] = dangling_sum/n_pages;
      kv->add((char*)&i,sizeof(float),(char *) imp_contri,sizeof(float)*2);
    }
  }
  else
  {
    for(int i=0; i<nvalues;i++)
    {
      kv->add(key,sizeof(float),multivalue + offset,valuebytes[i]);
      offset+=valuebytes[i];
    }
  }
}


void map_imp(uint64_t itask, char *key, int keybytes, char *value, int valuebytes, KeyValue *kv, void *ptr)
{
  kv->add(key,keybytes,value,sizeof(float));
}

void map_imp_diff(uint64_t itask, char *key, int keybytes, char *value, int valuebytes, KeyValue *kv, void *ptr)
{
  importance[0] += std::abs(importance[int(*(float*)key) + 1] - *(float*)value);
  importance[int(*(float*)key) + 1] = *(float*)value;
}
