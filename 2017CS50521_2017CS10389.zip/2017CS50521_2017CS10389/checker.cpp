// Copyright (c) 2009-2016 Craig Henderson
// https://github.com/cdmh/mapreduce

#include <bits/stdc++.h>


using namespace std;



void tokenize(string const &str, vector<string> &out)
{
    char *token = strtok(const_cast<char*>(str.c_str()), " ");
    while (token != nullptr)
    {
        out.push_back(string(token));
        token = strtok(nullptr, " ");
    }
}



float diff = 0;

int main(int argc, char *argv[])
{
    string f1 = argv[1];
    string f2 = argv[2];

    std::ifstream inFile1, inFile2;
    inFile1.open(f1);
    inFile2.open(f2);


    int count = 0;
    while(true)
    {
        string s1,s2;
        inFile1>>s1;
        inFile2>>s2;

        if(count%3==0)
        {
            if(s1=="s")
            {
                cout<<diff<<endl;
                break;
            }
        }
        else if(count%3==2)
            diff += abs(stof(s1) - stof(s2));

        count++;

    }


    inFile1.close();
    inFile2.close();


}
