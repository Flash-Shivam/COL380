#!/bin/bash


head="Executable, Input file, No. of processes, Time taken(s)"
echo $head > "$2"
# echo $head


filecontent=( `cat "$1" `)

for n in 1 2 4
do
    for line in "${filecontent[@]}"
    do
        filename="./test/$line.txt"
        answer_file="./test/$line-pr-p.txt"
        Part-A/mr-pr-cpp.o $filename -o output $n >> "$2"
        ./checker.o output $answer_file
    done
done



# run mr-pr-mpi
for n in 1 2 4
do
    for line in "${filecontent[@]}"
    do
        filename="./test/$line.txt"
        answer_file="./test/$line-pr-p.txt"
        mpirun -np $n --oversubscribe ./Part-B/mr-pr-mpi.o $filename -o output >> "$2"
        ./checker.o output $answer_file
    done
done

# run mr-pr-mpi-base
for n in 1 2 4
do
    for line in "${filecontent[@]}"
    do
        filename="./test/$line.txt"
        answer_file="./test/$line-pr-p.txt"
        mpiexec -np $n --oversubscribe ./Part-C/user/mr-pr-mpi-base.o $filename -o output >> "$2"
        ./checker.o output $answer_file
    done
done
