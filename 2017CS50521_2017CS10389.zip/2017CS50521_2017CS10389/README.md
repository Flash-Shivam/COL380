For Part-A

	make for linux: make -f Makefile.linux
	make for mac: make -f Makefile.mac

	run: ./mr-pr-cpp.o ${filename}.txt -o ${filename}-pr-cpp.txt

For Part-B
	make: make
	run: ./mr-pr-mpi.o ${filename}.txt -o ${filename}-pr-mpi.txt

For Part-C
	make for linux: make -f Makefile.linux
	make for mac: make -f Makefile.mac
	
	rum: ./mr-pr-mpi-base.o ${filename}.txt -o ${filename}-pr-mpi-base.txt

Checker 
	compile: g++ checker.cpp -o checker.o
	rum: ./checker.o ${filename1}.txt ${filename2}.txt
