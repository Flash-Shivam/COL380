// Copyright (c) 2009-2016 Craig Henderson
// https://github.com/cdmh/mapreduce

#include <bits/stdc++.h>
#include <chrono>
#include <boost/config.hpp>
#if defined(BOOST_MSVC)
#   pragma warning(disable: 4127)

// turn off checked iterators to avoid performance hit
#   if !defined(__SGI_STL_PORT)  &&  !defined(_DEBUG)
#       define _SECURE_SCL 0
#       define _HAS_ITERATOR_DEBUGGING 0
#   endif
#endif

#include "mapreduce.hpp"


#define pii std::pair<int, int>
#define vvi std::vector< std::vector<int> >


float err_tol = 1e-5;
int max_loops = 100;

namespace pageRank {

vvi webLinks;
std::vector<float> importance;
int n_pages = 0;
float alpha = 0.85;
float dangling_sum = 0;


void readFile(std::string filename, vvi &webLinks)
{
    std::ifstream inFile;
    inFile.open(filename);

    n_pages = 0;
    int a,b,linkCount = 0;

    while (inFile>>a>>b)
    {
        n_pages = std::max({n_pages,a+1,b+1});
        linkCount++;
    }

    inFile.close();

    std::vector<int> v;
    webLinks.insert(webLinks.begin(), n_pages, v);

    inFile.open(filename);
    while(linkCount--)
    {
        inFile>>a>>b;
        webLinks[a].push_back(b);
    }

    for(int i=0;i<n_pages;i++)
        importance.push_back(1.0/n_pages);
}



template<typename MapTask>
class datasource : mapreduce::detail::noncopyable
{
  public:
    datasource() : sequence_(0)
    {
    }

    bool const setup_key(typename MapTask::key_type &key)
    {
        key = sequence_++;
        return sequence_ <= n_pages;
    }

    bool const get_data(typename MapTask::key_type const &key, typename MapTask::value_type &value)
    {
        value = importance[key];
        return true;
    }

  private:
    int sequence_;
};

struct mt1 : public mapreduce::map_task<int, float>
{
    template<typename Runtime>
    void operator()(Runtime &runtime, key_type const &key, value_type const &value) const
    {
        if(webLinks[key].size()==0)
            runtime.emit_intermediate(-1, value);
    }
};

struct rt1 : public mapreduce::reduce_task<int, float>
{
    template<typename Runtime, typename It>
    void operator()(Runtime &runtime, key_type const &key, It it, It ite) const
    {
        assert(key == -1);
        dangling_sum = 0;
        while(it!=ite)
        {
            dangling_sum+= *it;
            it++;
        }
    }
};


typedef
mapreduce::job<pageRank::mt1,
               pageRank::rt1,
               mapreduce::null_combiner,
               pageRank::datasource<pageRank::mt1>
> job1;




struct mt2 : public mapreduce::map_task<int, float>
{
    template<typename Runtime>
    void operator()(Runtime &runtime, key_type const &key, value_type const &value) const
    {
      int pageLinks = webLinks[key].size();

      runtime.emit_intermediate(key, 0);
      for(int i=0;i<pageLinks;i++)
      {
          value_type value = importance[key]/pageLinks;
          runtime.emit_intermediate(webLinks[key][i], value);
      }
    }
};

struct rt2 : public mapreduce::reduce_task<int, float>
{
    template<typename Runtime, typename It>
    void operator()(Runtime &runtime, key_type const &key, It it, It ite) const
    {

        float imp_sum = (1.0 - alpha)/n_pages + alpha*dangling_sum/n_pages;

        for (; it!=ite; ++it)
          imp_sum+=(alpha)*(*it);

        runtime.emit(key,fabs(imp_sum - importance[key]));

        importance[key] = imp_sum;
    }
};

typedef
mapreduce::job<pageRank::mt2,
               pageRank::rt2,
               mapreduce::null_combiner,
               pageRank::datasource<pageRank::mt2>
> job2;

} // namespace pageRank

int main(int argc, char *argv[])
{

    pageRank::readFile(argv[1], pageRank::webLinks);


    mapreduce::specification spec;
    int n_tasks;
    if (argc <=4)
      n_tasks = std::thread::hardware_concurrency();
    else
      n_tasks = std::atoi(argv[4]);

    spec.map_tasks = n_tasks;
    spec.reduce_tasks = n_tasks;

    // spec.reduce_tasks = 2;

    auto start = std::chrono::high_resolution_clock::now();





    for(int loop = 0;loop<max_loops;loop++)
    {
        // std::cout<<"On iter: "<<loop<<"\n";
        // std::cout<<"############\n\n";
        mapreduce::results result1, result2;

        // job.run<mapreduce::schedule_policy::sequential<pageRank::job> >(result);
        // job.run<mapreduce::schedule_policy::cpu_parallel<pageRank::job> >(result);
        pageRank::job1::datasource_type ds1;
        pageRank::job1 job1(ds1, spec);

        // #ifdef _DEBUG
            // job.run<mapreduce::schedule_policy::sequential<pageRank::job> >(result);
        // #else
        job1.run<mapreduce::schedule_policy::cpu_parallel<pageRank::job1> >(result1);
        // #endif

        // std::cout <<"\nMapReduce1 finished in " << result1.job_runtime.count() << "s with " << std::distance(job1.begin_results(), job1.end_results()) << " results\n\n";


        pageRank::job2::datasource_type ds2;
        pageRank::job2 job2(ds2, spec);

        // #ifdef _DEBUG
            // job.run<mapreduce::schedule_policy::sequential<pageRank::job> >(result);
        // #else
        job2.run<mapreduce::schedule_policy::cpu_parallel<pageRank::job2> >(result2);
        // #endif

        // std::cout <<"\nMapReduce2 finished in " << result2.job_runtime.count() << "s with " << std::distance(job2.begin_results(), job2.end_results()) << " results\n\n";



        float error = 0;
        for (auto it=job2.begin_results(); it!=job2.end_results(); ++it)
            error+=it->second;

        if(error<err_tol)
        {
            // std::cout<<"end loop: "<<loop<<" with error "<<error<<std::endl;
            break;
        }
    }

    auto end = std::chrono::high_resolution_clock::now();
    double time_taken = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();

    std::ofstream outFile;
    outFile.open(argv[3]);

    outFile<<std::fixed<<std::setprecision(15);


    float importance_sum = 0;
    for(int i=0;i<pageRank::n_pages;i++)
        {
            // // std::cout<<i<<" = "<<importance[i]<<"\n";
            outFile<<i<<" = "<<pageRank::importance[i]<<"\n";
            importance_sum+=pageRank::importance[i];
        }
    // std::cout<<"s = "<<importance_sum<<"\n";
    outFile<<"s = "<<importance_sum<<"\n";
    outFile.close();


    // std::cout<<"Time for pagerank(sec): "<<time_taken*1e-9<<std::endl;
    std::cout<<"mr-pr-cpp.cpp "<<argv[1]<<" "<<spec.reduce_tasks<<" "<<time_taken*1e-9<<std::endl;

    return 0;
}
